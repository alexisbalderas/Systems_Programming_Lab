#ifndef _ex22_h
#define _ex22_h
extern int THE_SIZE;
int get_age();
void set_age(int age);
double update_ratio(double ratio);
void print_size();
#endif